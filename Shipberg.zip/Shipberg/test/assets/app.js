function closeMenuAndGoTo(query) {
  document.querySelector('#hero-menu').classList.toggle('ft-menu--js-show')
  setTimeout(() => {
    const element = document.querySelector(query)
    window.scrollTo({
      top: element.getBoundingClientRect().top,
      behavior: 'smooth'
    })
  }, 250);
}

document.querySelector('#hero-menu').
  querySelectorAll('[href]').
  forEach(function (link) {
    link.onclick = function (event) {
      event.preventDefault()
      closeMenuAndGoTo(link.getAttribute('href'))
    }
  })
  document.addEventListener("DOMContentLoaded", function () {
    const section = document.getElementById("heading-section");
  
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            section.classList.add("visible");
          }
        });
      },
      { threshold: 0.1 }
    );
  
    observer.observe(section);
  });
  // JavaScript to observe the card and apply animation on scroll
  document.addEventListener("DOMContentLoaded", () => {
    const scrollCard = document.querySelector(".scroll-card");

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            scrollCard.classList.add("active"); // Add 'active' class when in view
          } else {
            scrollCard.classList.remove("active"); // Remove 'active' class when out of view
          }
        });
      },
      {
        threshold: 0.5, // Trigger animation when 50% of the card is visible
      }
    );

    observer.observe(scrollCard);
  });
   // Function to check if an element is in the viewport
   function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top >= 0 &&
      rect.left >= 0 &&
      rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
      rect.right <= (window.innerWidth || document.documentElement.clientWidth)
    );
  }

  // Add 'visible' class when the element is in the viewport
  function handleScroll() {
    const sections = document.querySelectorAll('.content-section');
    sections.forEach((section) => {
      if (isInViewport(section)) {
        section.classList.add('visible');
      }
    });
  }

  // Listen for scroll events
  window.addEventListener('scroll', handleScroll);

  // Trigger animations on page load (for elements already in view)
  document.addEventListener('DOMContentLoaded', handleScroll);
  
  // On my load animation
  window.addEventListener('scroll', function() {
    var section = document.getElementById('on-my-load');
    var sectionPosition = section.getBoundingClientRect().top;
    var viewportHeight = window.innerHeight;
  
    if (sectionPosition < viewportHeight) {
      section.style.animation = 'fadeIn 2s forwards';
    }
  });
  
// Function to observe when sections come into view
const observer = new IntersectionObserver(
  (entries, observer) => {
    entries.forEach((entry) => {
      if (entry.isIntersecting) {
        entry.target.classList.add("visible");
        observer.unobserve(entry.target);
      }
    });
  },
  { threshold: 0.5 } // Trigger when 50% of the section is in view
);

// Observe each section
document.querySelectorAll(".section").forEach((section) => {
  observer.observe(section);
});

